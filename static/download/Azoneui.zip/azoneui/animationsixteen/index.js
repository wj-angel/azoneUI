import AzAnimationSixteen from "./src/AzAnimationSixteen"

AzAnimationSixteen.install = function (Vue,opts) {
  Vue.component(AzAnimationSixteen.name,AzAnimationSixteen)
}

export default AzAnimationSixteen

