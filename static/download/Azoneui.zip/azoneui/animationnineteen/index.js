import AzAnimationNineteen from "./src/AzAnimationNineteen"

AzAnimationNineteen.install = function (Vue,opts) {
  Vue.component(AzAnimationNineteen.name,AzAnimationNineteen)
}

export default AzAnimationNineteen

