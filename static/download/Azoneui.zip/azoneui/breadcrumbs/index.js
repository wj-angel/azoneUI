import AzBreadCurmbs from "./src/AzBreadCurmbs"

AzBreadCurmbs.install = function (Vue,opts) {
  Vue.component(AzBreadCurmbs.name,AzBreadCurmbs)
}

export default AzBreadCurmbs

