import AzThreeShuffing from "./src/AzThreeShuffing"

AzThreeShuffing.install = function (Vue,opts) {
  Vue.component(AzThreeShuffing.name,AzThreeShuffing)
}

export default AzThreeShuffing

