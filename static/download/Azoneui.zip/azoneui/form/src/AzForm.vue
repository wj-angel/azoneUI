<template>
    <div class="table">
      <table>
        <tr>
          <td>你的</td>
          <td>他的</td>
          <td>谁的</td>
          <td>我的</td>
        </tr>
      </table>
    </div>
</template>

<script>
    export default {
        name: "AzForm"
    }
</script>

<style scoped>

</style>
