import AzTheForm from "./src/AzTheForm"

AzTheForm.install = function (Vue,opts) {
  Vue.component(AzTheForm.name,AzTheForm)
}

export default AzTheForm

