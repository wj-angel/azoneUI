import AzPaging from './src/AzPaging'

AzPaging.install = function (Vue,opts) {
  Vue.component(AzPaging.name,AzPaging)
}

export default AzPaging
