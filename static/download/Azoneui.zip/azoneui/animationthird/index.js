import AzAnimationThird from "./src/AzAnimationThird"

AzAnimationThird.install = function (Vue,opts) {
  Vue.component(AzAnimationThird.name,AzAnimationThird)
}

export default AzAnimationThird

