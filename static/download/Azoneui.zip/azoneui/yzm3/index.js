import AzYzmThree from "./src/AzYzmThree"
AzYzmThree.install = function (Vue,opts) {
  Vue.component(AzYzmThree.name,AzYzmThree)

}

export default AzYzmThree
