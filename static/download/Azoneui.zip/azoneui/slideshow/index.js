import AzSildeshowOne from './src/AzSildeshowOne'

AzSildeshowOne.install = function (Vue,opts) {
  Vue.component(AzSildeshowOne.name,AzSildeshowOne)
}

export default AzSildeshowOne
