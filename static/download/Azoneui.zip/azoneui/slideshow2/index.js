import AzSildeshowTwo from './src/AzSildeshowTwo'

AzSildeshowTwo.install = function (Vue,opts) {
  Vue.component(AzSildeshowTwo.name,AzSildeshowTwo)
}

export default AzSildeshowTwo
