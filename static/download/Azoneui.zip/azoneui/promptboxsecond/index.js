import AzPromptBoxSecond from "./src/AzPromptBoxSecond"

AzPromptBoxSecond.install = function (Vue,opts) {
  Vue.component(AzPromptBoxSecond.name,AzPromptBoxSecond)
}

export default AzPromptBoxSecond

