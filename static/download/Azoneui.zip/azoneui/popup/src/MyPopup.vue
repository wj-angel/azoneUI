<template>
    
</template>

<script>
    export default {
        name: "MyPopup"
    }
</script>

<style scoped>

</style>
