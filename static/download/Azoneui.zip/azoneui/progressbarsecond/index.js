import AzProgressBarSecond from "./src/AzProgressBarSecond"

AzProgressBarSecond.install = function (Vue,opts) {
  Vue.component(AzProgressBarSecond.name,AzProgressBarSecond)
}

export default AzProgressBarSecond

