import AzSildeshowThree from './src/AzSildeshowThree'

AzSildeshowThree.install = function (Vue,opts) {
  Vue.component(AzSildeshowThree.name,AzSildeshowThree)
}

export default AzSildeshowThree
